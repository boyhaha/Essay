
# 文本分块转向量

## 数据分块
采用 python 包 langchain 中的RecursiveCharacterTextSplitter 进行分块。chunk_size = 100, chunk_overlap = 20

## 向量化
text2vec-large-chinese

